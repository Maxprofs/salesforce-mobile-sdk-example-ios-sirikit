function Set-UnattendedWindowsPackage
{
    param
    (
        [string[]]$Package
    )
}