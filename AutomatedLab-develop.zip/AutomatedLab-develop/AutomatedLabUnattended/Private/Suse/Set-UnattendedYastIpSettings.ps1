function Set-UnattendedYastIpSettings
{
	param (
		[string]$IpAddress,
		
		[string]$Gateway,
		
		[String[]]$DnsServers,

        [string]$DnsDomain
    )
    
}