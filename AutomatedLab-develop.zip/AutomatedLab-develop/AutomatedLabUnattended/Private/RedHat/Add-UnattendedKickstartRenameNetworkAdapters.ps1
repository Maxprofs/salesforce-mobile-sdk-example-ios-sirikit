function Add-UnattendedKickstartRenameNetworkAdapters
{
    [CmdletBinding()]
    param ( )
    Write-Verbose -Message 'Method not yet implemented for RHEL/CentOS/Fedora'
}
