# PostInstallationActivities folder

AutomatedLab comes with some default customizations that are quite handy to deploy additional features. The content in this folder is quite static
and only the AutomatedLab Team is adding something here sometimes. The new way of adding new roles to AutomatedLab is through [Custom Roles](https://github.com/AutomatedLab/AutomatedLab/wiki/Custom-Roles).