# SoftwarePackages folder

AutomatedLab uses this default folder to store software that is being downloaded during the deployment of a lab. We recommend to put all
software that you want to deply in here as well to have all in one place.

This folder is hard-coded in many places hence should not be renamed.